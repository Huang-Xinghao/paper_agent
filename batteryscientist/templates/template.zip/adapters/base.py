"""Contract for adding prediction domains without copying the experiment loop."""

from abc import ABC, abstractmethod


class PredictionAdapter(ABC):
    # forward returns {task: (prediction, scaled_target, boolean_observed_mask)}.
    # decode converts prediction/target to original evaluation units.
    # state must be JSON-serializable and include split manifests and all scalers.
    @abstractmethod
    def loaders(self, state=None):
        """Build train/validation/test, restoring preprocessing when state is supplied."""

    @abstractmethod
    def state(self):
        """Return preprocessing, data provenance and split membership."""

    @abstractmethod
    def forward(self, model, batch, device):
        """Adapt model outputs and observed task targets for shared loss computation."""

    @abstractmethod
    def decode(self, task, prediction, target, batch):
        """Convert standardized arrays to original task units."""

    @abstractmethod
    def samples(self, batch):
        """Return stable sample identifiers in batch order."""

    def extras(self, decoded, batch):
        """Optional derived outputs saved alongside task predictions."""
        return {}
