"""Domain plugins: data, task targets, model inputs and evaluation transforms."""

from .cell import CellAdapter
from .electrolyte import ElectrolyteAdapter

ADAPTERS = {'cell': CellAdapter, 'electrolyte': ElectrolyteAdapter}


def make_adapter(args):
    domain = getattr(args, 'domain', 'cell')
    if domain not in ADAPTERS:
        raise ValueError(f'Unknown domain {domain!r}; choose from {tuple(ADAPTERS)}')
    return ADAPTERS[domain](args)
