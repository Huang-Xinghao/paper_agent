"""Register model factories here; adapters declare compatible models."""

from .IC2ML import Model as IC2ML
from .CompositionMLP import Model as CompositionMLP

MODELS = {'IC2ML': IC2ML, 'CompositionMLP': CompositionMLP}


def build_model(args):
    if args.model not in MODELS:
        raise ValueError(f'Unknown model {args.model!r}; choose from {tuple(MODELS)}')
    return MODELS[args.model](args).float()
